Thank you for downloading Multiply
Please note: You will have to extract the zip folder to play the game